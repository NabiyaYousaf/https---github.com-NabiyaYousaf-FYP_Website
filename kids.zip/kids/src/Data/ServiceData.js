const Services=[
    {
        id:1,
        description:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus consequatur sequi numquam laboriosam?",
        class:"Class One",
        animation:"fade-right"
    },
    {
        id:2,
        description:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus?",
        class:"Class Two",
        animation:"fade-down"
    },
    {
        id:3,
        description:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus consequatur sequi numquam laboriosam?",
        class:"Class Three",
        animation:"fade-left"
    }
]
export default Services;