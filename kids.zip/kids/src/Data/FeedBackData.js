import img from './images/p1.jpg';
const FeedBack=[
    {
        id:1,
        feedback:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus consequatur sequi numquam laboriosam?",
        name:"johnn",
        image:img
    },
    {
        id:2,
        feedback:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus?",
        name:"Steve",
        image:img
    },
    {
        id:3,
        feedback:"Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero earum temporibus consequatur sequi numquam laboriosam?",
        name:"Mack",
        image:img
    }
]
export default FeedBack;