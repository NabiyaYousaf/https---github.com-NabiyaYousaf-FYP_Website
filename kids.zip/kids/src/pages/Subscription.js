import React from 'react'
import Navbar from './Navbar';
const Subscription = () => {
  return (
    <>
    <Navbar/>
        <h1>Subscription Page</h1>
    </>
  )
}

export default Subscription
